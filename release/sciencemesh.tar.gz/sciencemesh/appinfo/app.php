<?php
declare(strict_types=1);

$app = \OC::$server->query(\OCA\ScienceMesh\AppInfo\ScienceMeshApp::class);
