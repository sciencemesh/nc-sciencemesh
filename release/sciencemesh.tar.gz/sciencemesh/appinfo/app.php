<?php
declare(strict_types=1);
use OCP\Util;

$app = \OC::$server->query(\OCA\ScienceMesh\AppInfo\ScienceMeshApp::class);
