<ul class="with-icon">
    <li><a class="icon-contacts-dark" style="padding-left:34px" href="contacts">ScienceMesh Contacts</a></li>
</ul>