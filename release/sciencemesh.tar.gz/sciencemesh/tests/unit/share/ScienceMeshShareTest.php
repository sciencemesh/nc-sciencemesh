<?php

namespace OCA\ScienceMesh\Tests\Unit;

use PHPUnit_Framework_TestCase;

class ScienceMeshShareTest extends PHPUnit_Framework_TestCase {
	//remove warning, delete after real tests get into the branch
	public function testNothing() {
		$this->assertEquals(true, true);
	}
	/*
		public function testFromJson() {  //TODO
			return(false);
		}

		public function testScienceMeshId() {  //TODO
			return(false);
		}

		public function testScienceMeshResourceId() {  //TODO
			return(false);
		}

		public function testScienceMeshPermissions() {  //TODO
			return(false);
		}

		public function testScienceMeshGrantee() {  //TODO
			return(false);
		}

		public function testScienceMeshOwner() {  //TODO
			return(false);
		}

		public function testScienceMeshCreator() {  //TODO
			return(false);
		}

		public function testScienceMeshCtime() {  //TODO
			return(false);
		}

		public function testScienceMeshMtime() {  //TODO
			return(false);
		}

		public function testShareId() {  //TODO
			return(false);
		}

		public function testShareFullId() {  //TODO
			return(false);
		}

		public function testShareNode() {  //TODO
			return(false);
		}

		public function testShareType() {  //TODO
			return(false);
		}

		public function testSharedWith() {  //TODO
			return(false);
		}

		public function testSharedWithDisplayName() {  //TODO
			return(false);
		}

		public function testSharedWithAvatar() {  //TODO
			return(false);
		}

		public function testSharePermisions() {  //TODO
			return(false);
		}

		public function testShareStatus() {  //TODO
			return(false);
		}

		public function testShareNote() {  //TODO
			return(false);
		}

		public function testShareExpirationDate() {  //TODO
			return(false);
		}

		public function testShareLabel() {  //TODO
			return(false);
		}

		public function testSharedBy() {  //TODO
			return(false);
		}

		public function testShareOwner() {  //TODO
			return(false);
		}

		public function testSharePassword() {  //TODO
			return(false);
		}

		public function testShareSendPasswordByTalk() {  //TODO
			return(false);
		}

		public function testShareToken() {  //TODO
			return(false);
		}

		public function testShareTarget() {  //TODO
			return(false);
		}

		public function testShareTime() {  //TODO
			return(false);
		}

		public function testShareMailSend() {  //TODO
			return(false);
		}

		public function testShareNodeCacheEntry() {  //TODO
			return(false);
		}

		public function testShareHideDownload() {  //TODO
			return(false);
		}*/
}
