//I just seperate logic my module I mean if you are just use one file JS when you are go to another file it will
//give some error you need for every PHP file seperate JS logic
document.addEventListener("DOMContentLoaded", function(event) {
    $('#test').hide();
    
});